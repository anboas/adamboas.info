/* requirements object description rollover - start */
var reqlMiniInfo = new Object();
reqlMiniInfo.divIDFragment = "reqlMiniInfo__rolloverDescription_load";
// Description cache
reqlMiniInfo.descriptions = [];
reqlMiniInfo.initialDesc = null;

reqlMiniInfo.mouseEvent = new Object();

// Div Window Time To Live
reqlMiniInfo.displayTTL = 500;

// Div Window wait before call
reqlMiniInfo.initTime = 250;

reqlMiniInfo.offset = new Object();
reqlMiniInfo.offset.y = 4;
reqlMiniInfo.offset.x = 6;

reqlMiniInfo.timer = null;
reqlMiniInfo.currectDisplay = null;

reqlMiniInfo.getDisplayDiv = function(rowId) {
    var displayDiv = document.getElementById(reqlMiniInfo.divIDFragment);
    return displayDiv;
}

reqlMiniInfo.makeRequest = function(rowId) {
    var descSpan = document.getElementById(rowId);
    var desc = descSpan.innerHTML;
    desc = reqlMiniInfo.decorateDesc(desc);
    document.reqlMiniInfo.descriptions[rowId] = desc;
    document.reqlMiniInfo.displayDescription(null, rowId);

};

reqlMiniInfo.decorateDesc = function(desc) {
    var maxHeight = "200";
    var maxWidth = "400";
    var strLable = document.getElementById("descLabel").innerHTML;
    var htmlDesc = "<div valign='top' width='100%' style='text-align: center; color: white; font-size:12px;"
            + " background-color: rgb(64, 99, 122); padding: 2px 9px 3px 9px;'><strong>"
            + strLable
            + "</strong></div>"
            + "<div style='padding: 2px 8px; overflow: auto; max-height: "
            + maxHeight
            + "px; max-width: "
            + maxWidth
            + "px; width: expression("
            + maxWidth
            + "+\"px\"); height: expression(this.scrollHeight > "
            + maxHeight
            + " ? \""
            + maxHeight
            + "px\" : this.scrollHeight);' class=ppdata>"
            + desc + "</div>";
    return htmlDesc;

};

reqlMiniInfo.displayDescription = function(mouseEvent, rowId) {
    var outputDiv = reqlMiniInfo.getDisplayDiv(rowId);
    var description = reqlMiniInfo.descriptions[rowId];

    // Still waiting to retrieve the description
    if (description == 1) {
        if (reqlMiniInfo.initialDesc == null) {
            // init the 'waiting message' if not already set
            reqlMiniInfo.initialDesc = outputDiv.innerHTML;
            description = reqlMiniInfo.initialDesc;
        } else {
            // Use the saved 'waiting message'
            description = reqlMiniInfo.initialDesc;
        }
    }

    if (outputDiv != null) {

        outputDiv.innerHTML = description;

        if (mouseEvent && mouseEvent != null) {
            reqlMiniInfo.hideDescription();
            outputDiv.style.display = "";
            reqlMiniInfo.currectDisplay = rowId;
        }
        reqlMiniInfo.repositionDescriptionDiv(outputDiv);
    }
};

reqlMiniInfo.repositionDescriptionDiv = function(outputDiv) {
    if (reqlMiniInfo.mouseEvent.y + outputDiv.offsetHeight
            + reqlMiniInfo.offset.y > document.body.clientHeight
            + reqlMiniInfo.mouseEvent.scrollTop) {
        var ceiling = reqlMiniInfo.mouseEvent.y - outputDiv.offsetHeight;
        outputDiv.style.top = ceiling < reqlMiniInfo.mouseEvent.scrollTop ? (reqlMiniInfo.mouseEvent.scrollTop + "px")
                : (ceiling + "px");
    } else {
        outputDiv.style.top = reqlMiniInfo.mouseEvent.y + reqlMiniInfo.offset.y + "px";
    }
    outputDiv.style.left = reqlMiniInfo.mouseEvent.x + reqlMiniInfo.offset.x + "px";
};

reqlMiniInfo.stopHideDescription = function() {
    clearTimeout(reqlMiniInfo.timer);
};

reqlMiniInfo.hideDescriptionTimer = function() {
    clearTimeout(reqlMiniInfo.timer);
    reqlMiniInfo.timer = setTimeout("document.reqlMiniInfo.hideDescription();",reqlMiniInfo.displayTTL);
};

reqlMiniInfo.hideDescription = function() {
    if (reqlMiniInfo.currectDisplay != null) {
        reqlMiniInfo.getDisplayDiv(reqlMiniInfo.currectDisplay).style.display = "none";
        reqlMiniInfo.currectDisplay = null;
    }
};

/*
 * Clear timer Store mouseEvent that caused this function to get called Set
 * timer to showDescription(mouseEvent, rowId)
 */
reqlMiniInfo.getDescription = function(mouseEvent, rowId) {
    // Pull out needed info from the calling event (passing by value)
    // NOTE (As to why):
    // IE's event is a global var and it cannot be reliably passed by reference
    var displayDiv = document
            .getElementById(reqlMiniInfo.divIDFragment + rowId);

    var posx = posy = scrollLeft = scrollTop = 0;
    var obj = mouseEvent.target || mouseEvent.srcElement;

    if (mouseEvent.pageX || mouseEvent.pageY) {
        posx = mouseEvent.pageX;
        posy = mouseEvent.pageY;
        scrollTop = document.body.scrollTop;
    } else if (mouseEvent.clientX || mouseEvent.clientY) {
        posx = mouseEvent.clientX + document.documentElement.scrollLeft
                + document.body.scrollLeft;
        posy = mouseEvent.clientY + document.documentElement.scrollTop
                + document.body.scrollTop;
        scrollTop = document.body.scrollTop
                + document.documentElement.scrollTop;
    }

    /*
     * Dynamically set the offset.x and offset.y based on the width and height
     * of this table cell.
     */

    var targetObject = mouseEvent.target || mouseEvent.srcElement;

    if (targetObject && targetObject != null) {

    }

    if (targetObject && targetObject != null) {
        var containingElement = targetObject.parentNode;
        reqlMiniInfo.offset.x = containingElement.scrollWidth;
        reqlMiniInfo.offset.y = containingElement.parentNode.scrollHeight;

        var totalX = 0;
        var totalY = -1;
        while (targetObject && targetObject != null) {
            totalX += targetObject.offsetLeft - targetObject.scrollLeft;
            totalY += targetObject.offsetTop - targetObject.scrollTop;
            targetObject = targetObject.offsetParent;
        }
        posx = totalX + document.body.scrollLeft
                + document.documentElement.scrollLeft;
        posy = totalY + scrollTop;
    }

    reqlMiniInfo.mouseEvent.x = posx;
    reqlMiniInfo.mouseEvent.y = posy;
    reqlMiniInfo.mouseEvent.scrollTop = scrollTop;
    // END event storing

    clearTimeout(reqlMiniInfo.timer);
    reqlMiniInfo.timer = setTimeout(
            "document.reqlMiniInfo.showDescription(document.reqlMiniInfo.mouseEvent, '"
                    + rowId + "');", reqlMiniInfo.initTime);
};

reqlMiniInfo.showDescription = function(mouseEvent, rowId) {
    var description = reqlMiniInfo.descriptions[rowId];
    reqlMiniInfo.descriptions[rowId] = 1;
    reqlMiniInfo.displayDescription(mouseEvent, rowId);
    reqlMiniInfo.timer = setTimeout("document.reqlMiniInfo.makeRequest( '"
            + rowId + "');", reqlMiniInfo.displayTTL);
};

document.reqlMiniInfo = reqlMiniInfo;
/* requirements object description rollover - end */